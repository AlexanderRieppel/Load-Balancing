package balance;
/**
 * Interface fuer Konsolenbefehle
 * @author Thomas Traxler
 *
 */
public interface Befehl {
	
	public void execute (String[] args);

}
